<?php
//1. Creen una interfaz llamada Detalle con el siguiente método:
//obtenerDetallesEspecificos(): string
interface Detalle {
    public function obtenerDetallesEspecificos(): string;
}

?>